# -*- coding: utf-8 -*-
import os
import pandas as pd

from config import SUPPORTED_EXTENSIONS


def get_file_extension(filename):
    _, ext = os.path.splitext(filename)
    return ext.lower()


def is_supported_file(filename):
    return get_file_extension(filename) in SUPPORTED_EXTENSIONS


def load_file_to_df(file_path, sheet_name=0):
    ext = get_file_extension(file_path)
    try:
        if ext == ".csv":
            df = pd.read_csv(file_path)
        elif ext in (".xlsx", ".xls"):
            df = pd.read_excel(file_path, sheet_name=sheet_name, dtype_backend="numpy_nullable")
        else:
            return None, f"不支持的文件格式: {ext}"
        return df, None
    except Exception as e:
        return None, str(e)


def get_sheet_names(file_path):
    ext = get_file_extension(file_path)
    if ext in (".xlsx", ".xls"):
        try:
            xls = pd.ExcelFile(file_path)
            return xls.sheet_names, None
        except Exception as e:
            return [], str(e)
    elif ext == ".csv":
        return ["Sheet1"], None
    return [], "不支持的文件格式"


def infer_column_types(df):
    types = {}
    for col in df.columns:
        dtype = df[col].dtype
        if pd.api.types.is_integer_dtype(dtype) or pd.api.types.is_float_dtype(dtype):
            types[col] = "numerical"
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            types[col] = "datetime"
        elif pd.api.types.is_bool_dtype(dtype):
            types[col] = "boolean"
        elif pd.api.types.is_object_dtype(dtype):
            sample = df[col].dropna()
            if len(sample) > 0:
                try:
                    pd.to_datetime(sample.iloc[:100])
                    types[col] = "datetime"
                except (ValueError, TypeError):
                    types[col] = "text"
            else:
                types[col] = "text"
        else:
            types[col] = "text"
    return types


def get_column_profile(df):
    types = infer_column_types(df)
    profile = []
    for i, col in enumerate(df.columns):
        non_null = df[col].notna().sum()
        total = len(df)
        null_count = total - non_null
        null_pct = round(null_count / total * 100, 2) if total > 0 else 0
        unique_count = int(df[col].nunique())
        samples = df[col].dropna().head(5).tolist()
        col_type = types[col]

        extra = {}
        if col_type == "numerical":
            numeric_vals = pd.to_numeric(df[col], errors="coerce")
            extra["min"] = round(float(numeric_vals.min()), 2) if not pd.isna(numeric_vals.min()) else None
            extra["max"] = round(float(numeric_vals.max()), 2) if not pd.isna(numeric_vals.max()) else None
            extra["mean"] = round(float(numeric_vals.mean()), 2) if not pd.isna(numeric_vals.mean()) else None
        elif col_type == "text":
            str_vals = df[col].dropna().astype(str)
            extra["min_length"] = int(str_vals.str.len().min()) if len(str_vals) > 0 else 0
            extra["max_length"] = int(str_vals.str.len().max()) if len(str_vals) > 0 else 0

        profile.append({
            "index": i + 1,
            "column": col,
            "type": col_type,
            "non_null": int(non_null),
            "non_null_pct": round(non_null / total * 100, 2) if total > 0 else 0,
            "null_count": int(null_count),
            "null_pct": null_pct,
            "unique_count": unique_count,
            "samples": samples,
            "extra": extra,
        })
    return profile


class FileStore:
    def __init__(self):
        self.files = {}

    def add_file(self, file_id, name, path, sheet_names):
        self.files[file_id] = {
            "name": name,
            "path": path,
            "sheet_names": sheet_names,
            "selected_sheet": sheet_names[0] if sheet_names else None,
            "df": None,
            "loaded": False,
        }

    def remove_file(self, file_id):
        if file_id in self.files:
            del self.files[file_id]

    def select_sheet(self, file_id, sheet_name):
        if file_id in self.files:
            self.files[file_id]["selected_sheet"] = sheet_name
            self.files[file_id]["df"] = None
            self.files[file_id]["loaded"] = False

    def load_sheet_data(self, file_id):
        if file_id not in self.files:
            return None, "文件不存在"
        info = self.files[file_id]
        if info["loaded"] and info["df"] is not None:
            return info["df"], None
        df, err = load_file_to_df(info["path"], info["selected_sheet"])
        if err is None:
            info["df"] = df
            info["loaded"] = True
        return df, err

    def get_file_list(self):
        return [
            {
                "id": fid,
                "name": finfo["name"],
                "sheet_names": finfo["sheet_names"],
                "selected_sheet": finfo["selected_sheet"],
                "loaded": finfo["loaded"],
            }
            for fid, finfo in self.files.items()
        ]

    def get_loaded_dataframes(self):
        """Return list of (file_name, DataFrame) for all loaded files."""
        result = []
        for fid, finfo in self.files.items():
            if finfo["loaded"] and finfo["df"] is not None:
                result.append((finfo["name"], finfo["df"]))
        return result

    def get_merged_data(self):
        dfs = []
        names = []
        for fid, finfo in self.files.items():
            if finfo["loaded"] and finfo["df"] is not None:
                df = finfo["df"].copy()
                df["_source_file"] = finfo["name"]
                dfs.append(df)
                names.append(finfo["name"])
        if not dfs:
            return None, []
        merged = pd.concat(dfs, ignore_index=True)
        return merged, names

    def clear(self):
        self.files = {}

    def get_file_count(self):
        return len(self.files)

    def get_loaded_count(self):
        return sum(1 for f in self.files.values() if f["loaded"])
