# -*- coding: utf-8 -*-
"""Column profile view — shows detailed header attributes after import."""
from modules.file_manager import get_column_profile


def get_profile_data(df):
    """Get column profile data for display.
    Returns list of dicts with: index, column, type, non_null, null_count,
    null_pct, unique_count, samples, extra.
    """
    return get_column_profile(df)


def get_profile_summary(profile):
    """Get summary counts from profile data."""
    type_counts = {}
    for p in profile:
        t = p["type"]
        type_counts[t] = type_counts.get(t, 0) + 1

    total_cols = len(profile)
    total_nulls = sum(p["null_count"] for p in profile)
    total_uniques = sum(p["unique_count"] for p in profile)
    return {
        "total_columns": total_cols,
        "type_counts": type_counts,
        "total_nulls": total_nulls,
        "total_uniques": total_uniques,
    }


def get_column_names(profile):
    """Get list of column names from profile."""
    return [p["column"] for p in profile]


def get_column_types_dict(profile):
    """Get dict of column -> type."""
    return {p["column"]: p["type"] for p in profile}
