# -*- coding: utf-8 -*-
import pandas as pd
from thefuzz import fuzz


def exact_duplicates(df, columns):
    """Find exact duplicates based on specified column names."""
    if not columns:
        return pd.DataFrame()
    dup_mask = df.duplicated(subset=columns, keep=False)
    result = df[dup_mask].copy()
    if len(result) > 0:
        key_col = columns[0] if len(columns) > 0 else df.columns[0]
        result["_dup_count"] = result.groupby(columns)[key_col].transform("count")
    return result


def fuzzy_duplicates(df, column, threshold=85):
    """Find fuzzy duplicates in a single text column using Levenshtein distance."""
    values = df[column].dropna().astype(str).unique()
    if len(values) < 2:
        return pd.DataFrame()

    pairs = []
    for i in range(len(values)):
        for j in range(i + 1, len(values)):
            ratio = fuzz.ratio(values[i], values[j])
            if ratio >= threshold:
                pairs.append((values[i], values[j], ratio))

    if not pairs:
        return pd.DataFrame()

    all_matched = set()
    for a, b, r in pairs:
        all_matched.add(a)
        all_matched.add(b)

    result = df[df[column].astype(str).isin(all_matched)].copy()
    return result


def cross_file_duplicates(files_data, column):
    """
    Find duplicates across multiple files.
    files_data: list of (file_name, DataFrame)
    Returns DataFrame with _source_file and _dup_across_files columns.
    """
    if len(files_data) < 2:
        return pd.DataFrame()

    all_values = {}
    for fname, df in files_data:
        if column not in df.columns:
            continue
        vals = set(df[column].dropna().astype(str).unique())
        for v in vals:
            if v not in all_values:
                all_values[v] = []
            all_values[v].append(fname)

    dup_values = {v: files for v, files in all_values.items() if len(files) > 1}
    if not dup_values:
        return pd.DataFrame()

    rows = []
    for fname, df in files_data:
        if column not in df.columns:
            continue
        mask = df[column].astype(str).isin(dup_values.keys())
        matched = df[mask].copy()
        if len(matched) > 0:
            matched["_source_file"] = fname
            matched["_dup_across_files"] = matched[column].astype(str).map(
                lambda v: ", ".join(dup_values.get(v, []))
            )
            rows.append(matched)

    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def cross_file_intersection(files_data, column):
    """Find values that exist in ALL files."""
    if len(files_data) < 2:
        return pd.DataFrame()
    common = None
    for fname, df in files_data:
        if column not in df.columns:
            return pd.DataFrame()
        vals = set(df[column].dropna().astype(str).unique())
        if common is None:
            common = vals
        else:
            common = common & vals
    if not common:
        return pd.DataFrame()
    rows = []
    for fname, df in files_data:
        mask = df[column].astype(str).isin(common)
        matched = df[mask].copy()
        if len(matched) > 0:
            matched["_source_file"] = fname
            rows.append(matched)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def cross_file_difference(files_data, column, target_file):
    """Find values unique to the target file (not in others)."""
    all_others = set()
    for fname, df in files_data:
        if fname == target_file or column not in df.columns:
            continue
        all_others.update(df[column].dropna().astype(str).unique())

    for fname, df in files_data:
        if fname == target_file and column in df.columns:
            mask = ~df[column].astype(str).isin(all_others)
            result = df[mask].copy()
            result["_source_file"] = fname
            return result
    return pd.DataFrame()


def get_dup_summary(result_df, columns):
    """Get summary stats for dedup results."""
    if result_df.empty:
        return {"total_dup_rows": 0, "total_groups": 0, "dup_rate": 0}
    total_rows = len(result_df)
    groups = result_df.groupby(columns).size().shape[0] if columns else 1
    return {
        "total_dup_rows": total_rows,
        "total_groups": groups,
        "dup_rate": 0,  # caller should compute against original total
    }
