# -*- coding: utf-8 -*-
import pandas as pd


def apply_text_filter(df, column, operator, value):
    if not value:
        return df
    val = str(value)
    if operator == "包含":
        return df[df[column].astype(str).str.contains(val, case=False, na=False)]
    elif operator == "不包含":
        return df[~df[column].astype(str).str.contains(val, case=False, na=False)]
    elif operator == "等于":
        return df[df[column].astype(str) == val]
    elif operator == "不等于":
        return df[df[column].astype(str) != val]
    elif operator == "以...开头":
        return df[df[column].astype(str).str.startswith(val, na=False)]
    elif operator == "以...结尾":
        return df[df[column].astype(str).str.endswith(val, na=False)]
    elif operator == "正则":
        try:
            return df[df[column].astype(str).str.contains(val, case=False, na=False, regex=True)]
        except Exception:
            return df
    return df


def apply_numeric_filter(df, column, operator, value):
    numeric_col = pd.to_numeric(df[column], errors="coerce")
    if operator == ">":
        return df[numeric_col > value]
    elif operator == ">=":
        return df[numeric_col >= value]
    elif operator == "<":
        return df[numeric_col < value]
    elif operator == "<=":
        return df[numeric_col <= value]
    elif operator == "=":
        return df[numeric_col == value]
    elif operator == "介于":
        v1, v2 = value
        return df[(numeric_col >= v1) & (numeric_col <= v2)]
    elif operator == "Top N":
        n = int(value) if value else 10
        top_threshold = numeric_col.nlargest(n).min()
        return df[numeric_col >= top_threshold]
    elif operator == "Bottom N":
        n = int(value) if value else 10
        bottom_threshold = numeric_col.nsmallest(n).max()
        return df[numeric_col <= bottom_threshold]
    elif operator == "高于均值":
        return df[numeric_col > numeric_col.mean()]
    elif operator == "低于均值":
        return df[numeric_col < numeric_col.mean()]
    return df


def apply_date_filter(df, column, operator, value):
    date_col = pd.to_datetime(df[column], errors="coerce")
    if operator == "精确日期":
        target = pd.to_datetime(value)
        return df[date_col.dt.date == target.date()]
    elif operator == "日期范围":
        start, end = value
        return df[(date_col >= pd.to_datetime(start)) & (date_col <= pd.to_datetime(end))]
    elif operator == "今年":
        return df[date_col.dt.year == pd.Timestamp.now().year]
    elif operator == "本月":
        now = pd.Timestamp.now()
        return df[(date_col.dt.year == now.year) & (date_col.dt.month == now.month)]
    elif operator == "本季度":
        now = pd.Timestamp.now()
        q_start = pd.Timestamp(now.year, ((now.month - 1) // 3) * 3 + 1, 1)
        return df[date_col >= q_start]
    return df


def apply_null_filter(df, column, operator):
    if operator == "为空":
        return df[df[column].isna()]
    elif operator == "非空":
        return df[df[column].notna()]
    return df


def apply_filters(df, conditions, logic="AND"):
    """Apply multiple filter conditions.
    conditions: list of dicts with keys: col, op, val, type
    """
    if not conditions:
        return df

    results = []
    for cond in conditions:
        col = cond.get("col")
        op = cond.get("op")
        val = cond.get("val")
        ctype = cond.get("type")
        if not col or not op:
            continue

        if ctype == "text":
            filtered = apply_text_filter(df, col, op, val or "")
        elif ctype == "numerical":
            filtered = apply_numeric_filter(df, col, op, val)
        elif ctype == "datetime":
            filtered = apply_date_filter(df, col, op, val)
        else:
            filtered = apply_null_filter(df, col, op)

        results.append(filtered)

    if not results:
        return df

    if logic == "AND":
        result = df.copy()
        for r in results:
            result = result.loc[result.index.isin(r.index)]
        return result
    else:
        combined = pd.concat(results).drop_duplicates()
        return combined


TEXT_OPERATORS = ["包含", "不包含", "等于", "不等于", "以...开头", "以...结尾", "正则"]
NUMERIC_OPERATORS = [">", ">=", "<", "<=", "=", "介于", "Top N", "Bottom N", "高于均值", "低于均值"]
DATE_OPERATORS = ["精确日期", "日期范围", "今年", "本月", "本季度"]
NULL_OPERATORS = ["为空", "非空"]
