# -*- coding: utf-8 -*-
import pandas as pd


def transform_sort(df, columns, ascending=True):
    """Sort dataframe by specified columns."""
    return df.sort_values(by=columns, ascending=ascending).reset_index(drop=True)


def transform_groupby(df, group_cols, agg_col, agg_func="sum"):
    """Group by specified columns and aggregate."""
    if agg_func == "count":
        return df.groupby(group_cols).size().reset_index(name="count")
    return df.groupby(group_cols)[agg_col].agg(agg_func).reset_index()


def transform_split_column(df, column, delimiter=" ", new_columns=None):
    """Split a column into multiple columns."""
    if column not in df.columns:
        return df, "列不存在"
    parts = df[column].astype(str).str.split(delimiter, expand=True)
    if new_columns:
        n = min(len(new_columns), parts.shape[1])
        for i in range(n):
            df[new_columns[i]] = parts[i]
    else:
        for i in range(parts.shape[1]):
            df[f"{column}_{i+1}"] = parts[i]
    return df, None


def transform_merge_columns(df, columns, new_column, separator=" "):
    """Merge multiple columns into one."""
    df[new_column] = df[columns].astype(str).apply(
        lambda row: separator.join(row.values), axis=1
    )
    return df


def transpose_dataframe(df):
    """Transpose rows and columns."""
    return df.transpose().reset_index()


def union_dataframes(dfs):
    """Vertically concatenate multiple dataframes."""
    return pd.concat(dfs, ignore_index=True)


def join_dataframes(left_df, right_df, on, how="inner"):
    """Join two dataframes on a key column."""
    return left_df.merge(right_df, on=on, how=how)
