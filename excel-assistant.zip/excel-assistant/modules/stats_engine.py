# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def get_overview_stats(df):
    """Get overall dataset statistics."""
    total_rows = len(df)
    total_cols = len(df.columns)
    complete_rows = len(df.dropna())
    null_rows = total_rows - complete_rows
    null_cells = int(df.isna().sum().sum())
    total_cells = total_rows * total_cols
    completeness = round((1 - null_cells / total_cells) * 100, 2) if total_cells > 0 else 0
    num_cols = len(df.select_dtypes(include=["number"]).columns)
    text_cols = len(df.select_dtypes(include=["object", "string"]).columns)
    return {
        "total_rows": total_rows,
        "total_cols": total_cols,
        "complete_rows": complete_rows,
        "null_rows": null_rows,
        "null_cells": null_cells,
        "completeness": completeness,
        "num_cols": num_cols,
        "text_cols": text_cols,
    }


def get_numerical_stats(df, columns):
    """Get descriptive statistics for numerical columns."""
    stats_data = []
    for col in columns:
        s = df[col].dropna()
        if len(s) == 0:
            continue
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        outliers = s[(s < lower) | (s > upper)]
        stats_data.append({
            "column": col,
            "count": int(len(s)),
            "mean": round(float(s.mean()), 2),
            "std": round(float(s.std()), 2),
            "min": round(float(s.min()), 2),
            "q25": round(float(q1), 2),
            "median": round(float(s.median()), 2),
            "q75": round(float(q3), 2),
            "max": round(float(s.max()), 2),
            "skew": round(float(s.skew()), 3),
            "outliers": len(outliers),
        })
    return stats_data


def plot_histogram(df, column, bins=30):
    """Generate histogram as bytes (PNG)."""
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(df[column].dropna(), bins=bins, color="#1976D2", alpha=0.7)
    ax.set_title(f"{column} 分布", fontsize=14)
    ax.set_xlabel(column)
    ax.set_ylabel("频数")
    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100)
    plt.close(fig)
    return buf.getvalue()


def get_text_frequency(df, column, top_n=10):
    """Get frequency distribution for a text column."""
    s = df[column].dropna().astype(str)
    freq = s.value_counts().reset_index()
    freq.columns = ["value", "count"]
    freq["pct"] = round(freq["count"] / len(s) * 100, 2)
    return freq.head(top_n)


def plot_text_frequency(freq_df, column, top_n=10):
    """Generate bar chart for text frequency as bytes (PNG)."""
    data = freq_df.head(top_n)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.barh(range(len(data)), data["count"].values, color="#2ca02c", alpha=0.7)
    ax.set_yticks(range(len(data)))
    ax.set_yticklabels(data["value"].values, fontsize=10)
    ax.set_title(f"「{column}」频率分布 Top {top_n}", fontsize=14)
    ax.set_xlabel("出现次数")
    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100)
    plt.close(fig)
    return buf.getvalue()


def get_correlation_matrix(df):
    """Get correlation matrix for numerical columns."""
    num_df = df.select_dtypes(include=["number"])
    if num_df.shape[1] < 2:
        return None
    return num_df.corr()


def plot_correlation_heatmap(corr_matrix):
    """Generate correlation heatmap as bytes (PNG)."""
    fig, ax = plt.subplots(figsize=(max(6, len(corr_matrix.columns) * 0.8),
                                     max(5, len(corr_matrix.columns) * 0.7)))
    im = ax.imshow(corr_matrix.values, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
    ax.set_xticks(range(len(corr_matrix.columns)))
    ax.set_yticks(range(len(corr_matrix.columns)))
    ax.set_xticklabels(corr_matrix.columns, rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(corr_matrix.columns, fontsize=9)
    for i in range(len(corr_matrix.columns)):
        for j in range(len(corr_matrix.columns)):
            ax.text(j, i, f"{corr_matrix.iloc[i, j]:.2f}", ha="center", va="center", fontsize=8)
    plt.colorbar(im, ax=ax, shrink=0.8)
    ax.set_title("相关系数矩阵", fontsize=14)
    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100)
    plt.close(fig)
    return buf.getvalue()


def build_pivot_table(df, index_col, columns_col, value_col, agg_func="count"):
    """Build a pivot table."""
    try:
        if not columns_col:
            pivot = df.groupby(index_col)[value_col].agg(agg_func).reset_index()
        else:
            pivot = df.pivot_table(
                index=index_col, columns=columns_col,
                values=value_col, aggfunc=agg_func
            ).fillna(0)
        return pivot, None
    except Exception as e:
        return None, str(e)


def get_missing_analysis(df):
    """Get missing value analysis."""
    null_counts = df.isna().sum()
    null_counts = null_counts[null_counts > 0]
    if len(null_counts) == 0:
        return pd.DataFrame(columns=["column", "missing_count", "missing_pct"])
    null_pct = (null_counts / len(df) * 100).round(2)
    result = pd.DataFrame({
        "column": null_counts.index,
        "missing_count": null_counts.values,
        "missing_pct": null_pct.values,
    }).sort_values("missing_pct", ascending=False)
    return result


def plot_missing_bars(missing_df):
    """Generate missing value bar chart as bytes (PNG)."""
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(missing_df["column"].astype(str), missing_df["missing_count"].values,
           color="#D32F2F", alpha=0.7)
    ax.set_title("缺失值分布", fontsize=14)
    ax.set_ylabel("缺失数")
    ax.tick_params(axis="x", rotation=45)
    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100)
    plt.close(fig)
    return buf.getvalue()
