# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np


def clean_null_values(df, method, fill_value=None):
    """Clean null values using specified method.
    method: "drop_rows", "drop_cols", "fill_mean", "fill_median",
            "fill_mode", "fill_value", "ffill", "bfill"
    """
    result = df.copy()
    if method == "drop_rows":
        result = result.dropna()
    elif method == "drop_cols":
        result = result.dropna(axis=1)
    elif method == "fill_mean":
        num_cols = result.select_dtypes(include=["number"]).columns
        for c in num_cols:
            result[c] = result[c].fillna(result[c].mean())
        for c in result.columns:
            if c not in num_cols:
                result[c] = result[c].fillna("")
    elif method == "fill_median":
        num_cols = result.select_dtypes(include=["number"]).columns
        for c in num_cols:
            result[c] = result[c].fillna(result[c].median())
        for c in result.columns:
            if c not in num_cols:
                result[c] = result[c].fillna("")
    elif method == "fill_mode":
        for c in result.columns:
            mode_val = result[c].mode()
            if len(mode_val) > 0:
                result[c] = result[c].fillna(mode_val[0])
    elif method == "fill_value":
        result = result.fillna(fill_value if fill_value is not None else "")
    elif method == "ffill":
        result = result.ffill()
    elif method == "bfill":
        result = result.bfill()
    return result


def remove_duplicates(df, subset=None, keep="first"):
    """Remove duplicate rows."""
    before = len(df)
    result = df.drop_duplicates(subset=subset if subset else None, keep=keep)
    removed = before - len(result)
    return result, removed


def clean_format(df, columns, trim=True):
    """Clean text columns: trim whitespace."""
    result = df.copy()
    for col in columns:
        if col in result.columns:
            if trim:
                result[col] = result[col].astype(str).str.strip()
                result[col] = result[col].replace("", np.nan)
    return result
