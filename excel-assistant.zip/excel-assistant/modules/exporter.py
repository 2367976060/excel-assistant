# -*- coding: utf-8 -*-
import os
import pandas as pd
from datetime import datetime
from config import OUTPUT_DIR


class ExcelExporter:
    """Export processed data to multi-sheet Excel file."""

    def __init__(self, output_dir=None):
        self.output_dir = output_dir or OUTPUT_DIR
        os.makedirs(self.output_dir, exist_ok=True)

    def export_all(self, raw_df, profile, dedup_result, filter_result,
                   stats_summary, cleaned_df, filename=None):
        """Export all results to a single multi-sheet Excel file.

        Args:
            raw_df: Original DataFrame
            profile: Column profile list
            dedup_result: Dedup result DataFrame (or None)
            filter_result: Filter result DataFrame (or None)
            stats_summary: Stats summary dict
            cleaned_df: Cleaned DataFrame (or None)
            filename: Custom filename (optional)
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"excel_assistant_export_{timestamp}.xlsx"

        filepath = os.path.join(self.output_dir, filename)

        with pd.ExcelWriter(filepath, engine="xlsxwriter") as writer:
            # Sheet 1: Raw data
            if raw_df is not None and not raw_df.empty:
                raw_df.to_excel(writer, sheet_name="原始数据", index=False)

            # Sheet 2: Column profile
            if profile:
                profile_df = pd.DataFrame(profile)
                profile_df.to_excel(writer, sheet_name="表头属性", index=False)

            # Sheet 3: Dedup result
            if dedup_result is not None and not dedup_result.empty:
                dedup_result.to_excel(writer, sheet_name="查重结果", index=False)

            # Sheet 4: Filter result
            if filter_result is not None and not filter_result.empty:
                filter_result.to_excel(writer, sheet_name="筛选结果", index=False)

            # Sheet 5: Stats summary
            if stats_summary:
                if isinstance(stats_summary, dict):
                    stats_df = pd.DataFrame([stats_summary])
                else:
                    stats_df = pd.DataFrame(stats_summary)
                stats_df.to_excel(writer, sheet_name="统计摘要", index=False)

            # Sheet 6: Cleaned data
            if cleaned_df is not None and not cleaned_df.empty:
                cleaned_df.to_excel(writer, sheet_name="清洗后数据", index=False)

        return filepath

    def export_dataframe(self, df, sheet_name="Sheet1", filename=None):
        """Export a single DataFrame to Excel."""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"export_{timestamp}.xlsx"
        filepath = os.path.join(self.output_dir, filename)
        df.to_excel(filepath, sheet_name=sheet_name, index=False)
        return filepath

    def export_report_with_images(self, raw_df, chart_images, filename=None):
        """Export data + embedded chart images to Excel."""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"report_{timestamp}.xlsx"
        filepath = os.path.join(self.output_dir, filename)

        with pd.ExcelWriter(filepath, engine="xlsxwriter") as writer:
            if raw_df is not None and not raw_df.empty:
                raw_df.to_excel(writer, sheet_name="数据", index=False)

            if chart_images:
                workbook = writer.book
                for i, (title, img_bytes) in enumerate(chart_images):
                    ws = workbook.add_worksheet(title[:31])
                    ws.insert_image("A1", f"chart_{i}.png",
                                    {"image_data": img_bytes})
        return filepath
