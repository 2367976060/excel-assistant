[app]

# (str) Title of your application
title = Excel 表格助手

# (str) Package name
package.name = excelassistant

# (str) Package domain (needed for android/ios packaging)
package.domain = org.excel.assistant

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to include (patterns)
source.include_exts = py,png,jpg,kv,atlas,ttf,otf

# (list) List of inclusions using patterns
# source.include_patterns = assets/**, data/**

# (list) List of exclusions using patterns
# source.exclude_patterns = venv/, tests/, __pycache__/

# (str) Application versioning
version = 1.0.0

# (str) Application versioning (method 2)
# version.regex = __version__ = ['"](.*)['"]
# version.filename = %(source.dir)s/main.py

# (list) Application requirements
# comma separated e.g. requirements = sqlite3,kivy
requirements = python3,kivy>=2.3.0,kivymd>=2.0.0,pandas>=2.0.0,openpyxl>=3.1.0,numpy>=1.24.0,matplotlib>=3.8.0,thefuzz>=0.22.0,python-dateutil>=2.8.0,xlsxwriter>=3.1.0

# (str) Custom source folders for requirements
# requirements.source.kivy = /path/to/kivy

# (list) Garden requirements
# garden_requirements =

# (str) Presplash of the application
# presplash.filename = %(source.dir)s/data/presplash.png

# (str) Icon of the application
# icon.filename = %(source.dir)s/data/icon.png

# (str) Supported orientation (one of landscape, sensorLandscape, portrait or all)
orientation = portrait

# (list) List of service to declare
# services = NAME:ENTRYPOINT_TO_PY,NAME2:ENTRYPOINT2_TO_PY

#
# OSX Specific
#

#
# author = © Copyright Info

# change the major version of python used by the app
osx.python_version = 3

# Kivy version to use
osx.kivy_version = 2.3.0

#
# Android specific
#

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

# (string) Presplash background color (for new android toolchain)
# Supported formats: #RRGGBB #AARRGGBB
android.presplash_color = #FFFFFF

# (str) The color of the navigation bar in Android
# android.navigationbar_color = #1976D2

# (str) The title of the navigation bar in Android
# android.navigationbar_title = Excel 表格助手

# (list) Permissions
android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,MANAGE_EXTERNAL_STORAGE

# (int) Target Android API, should be as high as possible.
android.api = 33

# (int) Minimum API your APK will support.
android.minapi = 21

# (int) Android SDK version to use
android.sdk = 33

# (str) Android NDK version to use
android.ndk = 25b

# (bool) Use Android's private storage instead of external storage
android.private_storage = False

# (str) Android NDK directory (if not using the default)
# android.ndk_path =

# (str) Android SDK directory (if not using the default)
# android.sdk_path =

# (str) ANT directory (if not using the default)
# android.ant_path =

# (bool) If True, then skip trying to update the Android SDK
# This can be useful to get around build errors
android.skip_update = False

# (bool) If True, then automatically accept SDK license
# agreements. This is not recommended for real builds.
android.accept_sdk_license = True

# (str) Android entry point, default is 'org.kivy.android.PythonActivity'
# android.entrypoint = org.kivy.android.PythonActivity

# (str) Activity name for the activity
# android.activity_name =

# (list) List of Java files to add to the android project
# android.add_src =

# (str) Python for android branch to use (default is develop)
# android.p4a_branch = develop

# (list) Python for android git branches to try in order
# android.p4a_branches = develop, master

# (str) The branch name of the p4a project to use
# android.p4a_branch = develop

# (str) The git url of the p4a project
# android.p4a_url = https://github.com/kivy/python-for-android.git

# (list) Android architecture to build for
android.archs = arm64-v8a

# (str) Python for android distribution name
# android.dist_name = excelassistant

# (str) The Android logcat filter to use
# android.logcat_filters = *:S python:V

# (bool) Copy libraries instead of using symlinks
# android.copy_libs = 1

# (str) The Android logcat filter to use
# android.logcat_filters =

# (bool) Enable the android storage permissions
android.storage = auto

#
# iOS specific
#

# (str) Path to a custom kivy-ios folder
# ios.kivy_ios_dir = ../kivy-ios

# (str) iOS SDK version to use. For iOS >= 13, this should be >= 14.
# ios.sdk_version = 16.4

# (str) iOS deployment target
# ios.deployment_target = 13.0

# (list) Permissions for iOS
# ios.permissions =

#
# Windows specific
#

# (str) Windows SDK version to use
# win.sdk = 10.0.22621.0

# (str) Windows KIT version to use
# win.kit = 10

# (str) Windows build system to use. Default is 'vs'
# win.build_system = vs

#
# macOS specific
#

# (list) macOS frameworks to use
# macos.frameworks =

# (str) macOS deployment target
# macos.deployment_target = 10.15

# (str) macOS SDK version
# macos.sdk_version = 13.0

#
# Build configuration
#

# (str) The build directory
build_dir = .build

# (str) The build output directory
bin_dir = ./bin

# (str) The build output directory pattern
# bin_dir_pattern = ./bin

# (str) The build log file
# build_log = build.log

# (str) The build directory to use
# build_dir = ./.build

# (str) The android build directory
# android.build_dir = ./.android_build

# (str) The android build output directory
# android.bin_dir = ./bin

# (str) The android build log file
# android.build_log = android_build.log

# (bool) If True, the build will be run in a container
android.container = true
