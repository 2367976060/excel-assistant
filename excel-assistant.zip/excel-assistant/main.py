# -*- coding: utf-8 -*-
"""
Excel 表格助手 — Android APK
A mobile Excel data analysis tool built with KivyMD.
"""

import os
os.environ["KIVY_NO_ARGS"] = "1"

from kivy.lang import Builder
from kivy.core.window import Window
from kivy.utils import platform
from kivy.clock import Clock
from kivy.metrics import dp

from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.list import OneLineListItem, OneLineIconListItem, IconLeftWidget, MDList
from kivymd.uix.datatables import MDDataTable
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDRectangleFlatButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.spinner import MDSpinner
from kivymd.uix.textfield import MDTextField
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.snackbar import MDSnackbar
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.toolbar import MDTopAppBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image as KVImage
from kivy.core.image import Image as CoreImage

from config import APP_TITLE
from modules.file_manager import FileStore, get_sheet_names, get_column_profile
from modules.profile_view import get_profile_data, get_column_types_dict
from modules.dedup_engine import (
    exact_duplicates, fuzzy_duplicates,
    cross_file_duplicates, cross_file_intersection, cross_file_difference
)
from modules.filter_engine import apply_filters, TEXT_OPERATORS, NUMERIC_OPERATORS, DATE_OPERATORS
from modules.stats_engine import (
    get_overview_stats, get_numerical_stats, get_text_frequency,
    get_correlation_matrix, get_missing_analysis,
    plot_histogram, plot_text_frequency, plot_correlation_heatmap, plot_missing_bars,
    build_pivot_table
)
from modules.data_cleaner import clean_null_values, remove_duplicates, clean_format
from modules.data_transform import (
    transform_sort, transform_groupby, transform_split_column,
    transform_merge_columns, transpose_dataframe
)
from modules.exporter import ExcelExporter
from io import BytesIO

if platform != "android":
    Window.size = (420, 750)


# ─── File Screen ───────────────────────────────────────────────────────────

class FileScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="8dp")
        layout.add_widget(MDTopAppBar(title="📁 文件管理", elevation=2))

        self.file_count_label = MDLabel(text="无文件", size_hint_y=None, height=dp(30))
        layout.add_widget(self.file_count_label)

        btn_add = MDRectangleFlatButton(
            text="📂 添加 Excel 文件",
            size_hint=(1, None), height=dp(48),
            md_bg_color="#1976D2", text_color="ffffff",
        )
        btn_add.bind(on_release=lambda x: self.add_file())
        layout.add_widget(btn_add)

        btn_row = MDBoxLayout(size_hint_y=None, height=dp(40), spacing="8dp")
        btn_load = MDRectangleFlatButton(text="全选加载")
        btn_load.bind(on_release=lambda x: self.load_all())
        btn_clear = MDRectangleFlatButton(text="清空")
        btn_clear.bind(on_release=lambda x: self.clear_all())
        btn_row.add_widget(btn_load)
        btn_row.add_widget(btn_clear)
        layout.add_widget(btn_row)

        sv = ScrollView()
        self.file_list = MDList()
        sv.add_widget(self.file_list)
        layout.add_widget(sv)

        self.status_label = MDLabel(text="📂 请添加 Excel 文件", size_hint_y=None,
                                     height=dp(30), halign="center")
        layout.add_widget(self.status_label)
        self.add_widget(layout)

    def on_enter(self):
        self.refresh()

    def refresh(self):
        self.file_list.clear_widgets()
        for f in self.store.get_file_list():
            icon = "file-excel" if f["loaded"] else "file-excel-outline"
            item = OneLineIconListItem(text=f"{f['name']}  [{f['selected_sheet']}]")
            item.add_widget(IconLeftWidget(icon=icon))
            item.bind(on_release=lambda btn, fid=f["id"]: self.on_file_tap(fid))
            self.file_list.add_widget(item)
        self.file_count_label.text = f"已加载: {self.store.get_loaded_count()}/{self.store.get_file_count()} 个文件"
        self.update_status()

    def on_file_tap(self, file_id):
        f = self.store.files.get(file_id)
        if not f:
            return
        self._pending_file_id = file_id
        items = [MDRectangleFlatButton(text=s, on_release=lambda btn, s=s: self.select_sheet(s))
                 for s in f["sheet_names"]]
        self._sheet_dialog = MDDialog(
            title=f"选择 Sheet: {f['name']}",
            type="simple",
            items=items,
        )
        self._sheet_dialog.open()

    def select_sheet(self, sheet_name):
        if hasattr(self, '_sheet_dialog') and self._sheet_dialog:
            self._sheet_dialog.dismiss()
        file_id = getattr(self, '_pending_file_id', None)
        if file_id and sheet_name:
            self.store.select_sheet(file_id, sheet_name)
            df, err = self.store.load_sheet_data(file_id)
            if err:
                self.show_snackbar(f"加载失败: {err}")
            else:
                self.show_snackbar(f"已加载 {sheet_name} ({len(df)} 行)")
            self.refresh()

    def add_file(self):
        try:
            from androidstorage4kivy import Chooser
            Chooser(self._on_file_selected).choose_file()
        except ImportError:
            from tkinter import Tk, filedialog
            root = Tk()
            root.withdraw()
            path = filedialog.askopenfilename(
                filetypes=[("Excel files", "*.xlsx *.xls *.csv"), ("All files", "*.*")]
            )
            root.destroy()
            if path:
                self._load_file(path)

    def _on_file_selected(self, result):
        if not result or not result.get("selection"):
            return
        self._load_file(result["selection"][0])

    def _load_file(self, path):
        import os
        name = os.path.basename(path)
        ext = os.path.splitext(name)[1].lower()
        if ext not in (".xlsx", ".xls", ".csv"):
            self.show_snackbar(f"不支持的文件格式: {name}")
            return
        sheets, err = get_sheet_names(path)
        if err:
            self.show_snackbar(f"读取失败: {err}")
            return
        file_id = str(hash(path))
        self.store.add_file(file_id, name, path, sheets)
        self.show_snackbar(f"已添加: {name}")
        self.refresh()

    def remove_selected(self):
        fl = self.store.get_file_list()
        if fl:
            self.store.remove_file(fl[-1]["id"])
            self.refresh()

    def clear_all(self):
        self.store.clear()
        self.refresh()

    def load_all(self):
        count = 0
        for f in self.store.get_file_list():
            df, err = self.store.load_sheet_data(f["id"])
            if err is None:
                count += 1
        self.show_snackbar(f"已加载 {count} 个文件")
        self.refresh()

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()

    def update_status(self):
        loaded = self.store.get_loaded_count()
        self.status_label.text = f"✅ 已就绪 — {loaded} 个文件已加载" if loaded else "📂 请添加 Excel 文件"


# ─── Preview Screen ────────────────────────────────────────────────────────

class PreviewScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="📋 数据预览", elevation=2))
        self.status = MDLabel(text="暂无数据", size_hint_y=None, height=dp(30))
        layout.add_widget(self.status)

        sv = ScrollView()
        self.profile_box = MDList()
        sv.add_widget(self.profile_box)
        layout.add_widget(sv)

        self.table_box = MDBoxLayout(size_hint_y=0.6)
        layout.add_widget(self.table_box)
        self.add_widget(layout)

    def on_enter(self):
        self.refresh()

    def refresh(self):
        self.profile_box.clear_widgets()
        self.table_box.clear_widgets()

        merged, _ = self.store.get_merged_data()
        if merged is None or merged.empty:
            self.status.text = "暂无数据 — 请先添加并加载文件"
            return

        self.status.text = f"共 {len(merged)} 行 × {len(merged.columns)} 列"

        profile = get_column_profile(merged)
        type_counts = {}
        for p in profile:
            t = p["type"]
            type_counts[t] = type_counts.get(t, 0) + 1
        summary = " | ".join([f"{t}: {c}" for t, c in type_counts.items()])
        self.profile_box.add_widget(OneLineListItem(text=f"📋 表头属性 — {summary}"))

        for p in profile[:20]:  # Show first 20 columns
            null_str = f"⬜ 空值: {p['null_count']} ({p['null_pct']}%)"
            extra_str = ""
            extra = p.get("extra", {})
            if extra:
                parts = []
                for k in ("min", "max", "mean"):
                    if k in extra and extra[k] is not None:
                        parts.append(f"{k}={extra[k]}")
                if "min_length" in extra:
                    parts.append(f"最短={extra['min_length']}")
                if "max_length" in extra:
                    parts.append(f"最长={extra['max_length']}")
                extra_str = " | ".join(parts) if parts else ""
            item = OneLineListItem(
                text=f"{p['index']}. {p['column']}  [{p['type']}]  ✅{p['non_null']}  🆔{p['unique_count']}  {null_str}",
                secondary_text=extra_str,
            )
            self.profile_box.add_widget(item)

        # Data table
        max_cols = min(len(merged.columns), 6)
        cols = merged.columns[:max_cols].tolist()
        max_rows = min(len(merged), 100)
        row_data = []
        for i in range(max_rows):
            row_data.append([str(merged[c].iloc[i])[:15] for c in cols])

        table = MDDataTable(
            size_hint=(1, 1),
            column_data=[(c, dp(50)) for c in cols],
            row_data=row_data,
            use_pagination=True, rows_num=10,
        )
        self.table_box.add_widget(table)


# ─── Dedup Screen ──────────────────────────────────────────────────────────

class DedupScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self.result_table = None
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="🔍 查重", elevation=2))

        # Column selector
        layout.add_widget(MDLabel(text="查重列:", size_hint_y=None, height=dp(24)))
        from kivymd.uix.textfield import MDTextField
        self.col_input = MDTextField(hint_text="输入列名（如: 姓名）", size_hint_y=None, height=dp(48))
        layout.add_widget(self.col_input)

        # Mode tabs
        self.mode = "exact"
        from kivymd.uix.segmentedcontrol import MDSegmentedControl, MDSegmentedControlItem
        seg = MDSegmentedControl(size_hint_y=None, height=dp(40))
        seg.add_widget(MDSegmentedControlItem(text="精确查重"))
        seg.add_widget(MDSegmentedControlItem(text="跨文件查重"))
        seg.add_widget(MDSegmentedControlItem(text="模糊查重"))
        seg.bind(on_active=lambda s, v: setattr(self, 'mode', v.text[:2]))
        layout.add_widget(seg)

        btn = MDRectangleFlatButton(text="开始查重", size_hint=(1, None), height=dp(48),
                                     md_bg_color="#1976D2", text_color="ffffff")
        btn.bind(on_release=self.run_dedup)
        layout.add_widget(btn)

        self.result_label = MDLabel(text="", size_hint_y=None, height=dp(30))
        layout.add_widget(self.result_label)

        sv = ScrollView()
        self.result_box = MDBoxLayout(size_hint_y=None, height=dp(400))
        sv.add_widget(self.result_box)
        layout.add_widget(sv)

        self.add_widget(layout)

    def on_enter(self):
        pass

    def run_dedup(self, *args):
        self.result_box.clear_widgets()
        col = self.col_input.text.strip()
        if not col:
            self.show_snackbar("请输入列名")
            return

        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return

        if col not in merged.columns:
            self.show_snackbar(f"列「{col}」不存在")
            return

        if self.mode == "exact":
            result = exact_duplicates(merged, [col])
        elif self.mode == "cross":
            files = self.store.get_loaded_dataframes()
            if len(files) < 2:
                self.show_snackbar("跨文件查重至少需要 2 个文件")
                return
            result = cross_file_duplicates(files, col)
        else:
            result = fuzzy_duplicates(merged, col, 85)

        if result.empty:
            self.result_label.text = "✅ 未发现重复数据"
            return

        self.result_label.text = f"⚠️ 发现 {len(result)} 行重复"
        max_cols = min(len(result.columns), 5)
        cols = result.columns[:max_cols].tolist()
        max_rows = min(len(result), 80)
        row_data = []
        for i in range(max_rows):
            row_data.append([str(result[c].iloc[i])[:12] for c in cols])

        table = MDDataTable(
            size_hint=(1, 1),
            column_data=[(c, dp(50)) for c in cols],
            row_data=row_data,
            use_pagination=True, rows_num=8,
        )
        self.result_box.add_widget(table)

        self.store._dedup_result = result

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── Filter Screen ─────────────────────────────────────────────────────────

class FilterScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self.conditions = []
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="🔧 筛选", elevation=2))

        sv = ScrollView()
        form = MDBoxLayout(orientation="vertical", spacing="4dp", size_hint_y=None)
        form.bind(minimum_height=form.setter("height"))

        form.add_widget(MDLabel(text="筛选条件:", size_hint_y=None, height=dp(24)))
        self.col_input = MDTextField(hint_text="列名", size_hint_y=None, height=dp(44))
        form.add_widget(self.col_input)
        self.op_input = MDTextField(hint_text="条件 (包含/等于/>/介于...)", size_hint_y=None, height=dp(44))
        form.add_widget(self.op_input)
        self.val_input = MDTextField(hint_text="值", size_hint_y=None, height=dp(44))
        form.add_widget(self.val_input)

        btn_row = MDBoxLayout(size_hint_y=None, height=dp(40), spacing="4dp")
        b1 = MDRectangleFlatButton(text="添加条件")
        b1.bind(on_release=lambda x: self.add_cond())
        b2 = MDRectangleFlatButton(text="清空条件")
        b2.bind(on_release=lambda x: self.clear_conds())
        btn_row.add_widget(b1)
        btn_row.add_widget(b2)
        form.add_widget(btn_row)

        self.cond_label = MDLabel(text="条件列表: (空)", size_hint_y=None, height=dp(24))
        form.add_widget(self.cond_label)

        logic_box = MDBoxLayout(size_hint_y=None, height=dp(40), spacing="4dp")
        self.logic = "AND"
        b_and = MDRectangleFlatButton(text="AND")
        b_and.bind(on_release=lambda x: setattr(self, 'logic', 'AND'))
        b_or = MDRectangleFlatButton(text="OR")
        b_or.bind(on_release=lambda x: setattr(self, 'logic', 'OR'))
        logic_box.add_widget(b_and)
        logic_box.add_widget(b_or)
        form.add_widget(logic_box)

        btn_filter = MDRectangleFlatButton(text="应用筛选", size_hint=(1, None), height=dp(48),
                                            md_bg_color="#1976D2", text_color="ffffff")
        btn_filter.bind(on_release=self.apply_filter)
        form.add_widget(btn_filter)

        self.result_label = MDLabel(text="", size_hint_y=None, height=dp(30))
        form.add_widget(self.result_label)

        sv.add_widget(form)
        layout.add_widget(sv)

        self.table_box = MDBoxLayout(size_hint_y=0.4)
        layout.add_widget(self.table_box)
        self.add_widget(layout)

    def on_enter(self):
        pass

    def add_cond(self):
        col = self.col_input.text.strip()
        op = self.op_input.text.strip()
        val = self.val_input.text.strip()
        if col and op:
            self.conditions.append({"col": col, "op": op, "val": val, "type": "text"})
            self.cond_label.text = f"条件列表: {len(self.conditions)} 项"
            self.col_input.text = ""
            self.op_input.text = ""
            self.val_input.text = ""

    def clear_conds(self):
        self.conditions = []
        self.cond_label.text = "条件列表: (空)"

    def apply_filter(self, *args):
        self.table_box.clear_widgets()
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        if not self.conditions:
            self.show_snackbar("请添加筛选条件")
            return

        result = apply_filters(merged, self.conditions, self.logic)
        self.result_label.text = f"筛选结果: {len(result)} 行 (原始 {len(merged)} 行)"

        if not result.empty:
            max_cols = min(len(result.columns), 5)
            cols = result.columns[:max_cols].tolist()
            max_rows = min(len(result), 80)
            row_data = []
            for i in range(max_rows):
                row_data.append([str(result[c].iloc[i])[:12] for c in cols])
            table = MDDataTable(
                size_hint=(1, 1),
                column_data=[(c, dp(50)) for c in cols],
                row_data=row_data,
                use_pagination=True, rows_num=8,
            )
            self.table_box.add_widget(table)
            self.store._filter_result = result

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── Stats Screen ──────────────────────────────────────────────────────────

class StatsScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="📊 统计分析", elevation=2))
        self.status = MDLabel(text="暂无数据", size_hint_y=None, height=dp(30))
        layout.add_widget(self.status)

        sv = ScrollView()
        content = MDBoxLayout(orientation="vertical", spacing="6dp", size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Overview
        self.overview_label = MDLabel(text="", size_hint_y=None, height=dp(30))
        content.add_widget(self.overview_label)

        # Numerical
        content.add_widget(MDLabel(text="数值列统计:", size_hint_y=None, height=dp(24)))
        self.num_col_input = MDTextField(hint_text="列名", size_hint_y=None, height=dp(44))
        content.add_widget(self.num_col_input)
        btn_num = MDRectangleFlatButton(text="查看统计", size_hint=(1, None), height=dp(40))
        btn_num.bind(on_release=lambda x: self.show_num_stats())
        content.add_widget(btn_num)
        self.num_stats = MDLabel(text="", size_hint_y=None, height=dp(40))
        content.add_widget(self.num_stats)

        # Text
        content.add_widget(MDLabel(text="文本列频率:", size_hint_y=None, height=dp(24)))
        self.text_col_input = MDTextField(hint_text="列名", size_hint_y=None, height=dp(44))
        content.add_widget(self.text_col_input)
        btn_text = MDRectangleFlatButton(text="查看频率", size_hint=(1, None), height=dp(40))
        btn_text.bind(on_release=lambda x: self.show_text_freq())
        content.add_widget(btn_text)
        self.text_freq = MDLabel(text="", size_hint_y=None, height=dp(30))
        content.add_widget(self.text_freq)

        # Missing
        btn_miss = MDRectangleFlatButton(text="缺失值分析", size_hint=(1, None), height=dp(40))
        btn_miss.bind(on_release=lambda x: self.show_missing())
        content.add_widget(btn_miss)
        self.missing_label = MDLabel(text="", size_hint_y=None, height=dp(24))
        content.add_widget(self.missing_label)

        # Chart area
        self.chart_box = MDBoxLayout(size_hint_y=None, height=dp(250))
        content.add_widget(self.chart_box)

        sv.add_widget(content)
        layout.add_widget(sv)
        self.add_widget(layout)

    def on_enter(self):
        self.refresh()

    def refresh(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.status.text = "暂无数据"
            return
        self.status.text = f"数据: {len(merged)} 行 × {len(merged.columns)} 列"
        ov = get_overview_stats(merged)
        self.overview_label.text = (
            f"总行数: {ov['total_rows']:,} | 总列数: {ov['total_cols']} | "
            f"完整度: {ov['completeness']}% | 空值: {ov['null_cells']:,}"
        )

    def show_num_stats(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        col = self.num_col_input.text.strip()
        if not col or col not in merged.columns:
            self.show_snackbar(f"列「{col}」不存在")
            return
        stats = get_numerical_stats(merged, [col])
        if stats:
            s = stats[0]
            self.num_stats.text = (
                f"均值: {s['mean']} | 标准差: {s['std']} | "
                f"最小: {s['min']} | 最大: {s['max']} | 中位数: {s['median']}"
            )
            img = plot_histogram(merged, col)
            self._show_chart(img)

    def show_text_freq(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        col = self.text_col_input.text.strip()
        if not col or col not in merged.columns:
            self.show_snackbar(f"列「{col}」不存在")
            return
        freq = get_text_frequency(merged, col, 10)
        if not freq.empty:
            self.text_freq.text = f"唯一值: {freq['value'].nunique()} | Top: {freq.iloc[0]['value']} ({freq.iloc[0]['count']})"
            img = plot_text_frequency(freq, col)
            self._show_chart(img)

    def show_missing(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        missing = get_missing_analysis(merged)
        if missing.empty:
            self.missing_label.text = "✅ 无缺失值"
            return
        self.missing_label.text = f"{len(missing)} 列存在缺失值"
        img = plot_missing_bars(missing)
        self._show_chart(img)

    def _show_chart(self, img_data):
        self.chart_box.clear_widgets()
        core_img = CoreImage(BytesIO(img_data), ext="png")
        img_w = KVImage(texture=core_img.texture, size_hint=(1, None), height=dp(250))
        self.chart_box.add_widget(img_w)

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── Cleaner Screen ────────────────────────────────────────────────────────

class CleanerScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="🧹 数据清洗", elevation=2))

        sv = ScrollView()
        content = MDBoxLayout(orientation="vertical", spacing="6dp", size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Null cleaning
        content.add_widget(MDLabel(text="空值处理:", size_hint_y=None, height=dp(24)))
        self.null_method = MDTextField(hint_text="方法 (drop_rows/drop_cols/fill_mean)", size_hint_y=None, height=dp(44))
        content.add_widget(self.null_method)
        btn_null = MDRectangleFlatButton(text="执行空值清洗", size_hint=(1, None), height=dp(40))
        btn_null.bind(on_release=lambda x: self.run_null())
        content.add_widget(btn_null)

        # Dedup
        btn_dedup = MDRectangleFlatButton(text="删除重复行", size_hint=(1, None), height=dp(40))
        btn_dedup.bind(on_release=lambda x: self.run_dedup())
        content.add_widget(btn_dedup)

        # Format
        content.add_widget(MDLabel(text="格式清洗 (列名，用逗号分隔):", size_hint_y=None, height=dp(24)))
        self.format_cols = MDTextField(hint_text="列1, 列2", size_hint_y=None, height=dp(44))
        content.add_widget(self.format_cols)
        btn_fmt = MDRectangleFlatButton(text="去除空格", size_hint=(1, None), height=dp(40))
        btn_fmt.bind(on_release=lambda x: self.run_format())
        content.add_widget(btn_fmt)

        self.status = MDLabel(text="", size_hint_y=None, height=dp(24))
        content.add_widget(self.status)

        sv.add_widget(content)
        layout.add_widget(sv)
        self.add_widget(layout)

    def on_enter(self):
        pass

    def run_null(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        method = self.null_method.text.strip() or "drop_rows"
        result = clean_null_values(merged, method)
        self.store._clean_result = result
        before = merged.isna().sum().sum()
        after = result.isna().sum().sum()
        self.status.text = f"空值: {int(before)} → {int(after)}"
        self.show_snackbar(f"清洗完成: {len(merged)} → {len(result)} 行")

    def run_dedup(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        result, removed = remove_duplicates(merged)
        self.store._clean_result = result
        self.status.text = f"已删除 {removed} 行重复"
        self.show_snackbar(f"去重完成: {len(merged)} → {len(result)} 行")

    def run_format(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        cols = [c.strip() for c in self.format_cols.text.split(",") if c.strip()]
        result = clean_format(merged, cols if cols else merged.columns.tolist())
        self.store._clean_result = result
        self.status.text = "格式清洗完成"
        self.show_snackbar("格式清洗完成")

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── Transform Screen ──────────────────────────────────────────────────────

class TransformScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="🔄 数据转换", elevation=2))

        sv = ScrollView()
        content = MDBoxLayout(orientation="vertical", spacing="6dp", size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Sort
        content.add_widget(MDLabel(text="排序 (列名):", size_hint_y=None, height=dp(24)))
        self.sort_col = MDTextField(hint_text="列名", size_hint_y=None, height=dp(44))
        content.add_widget(self.sort_col)
        btn_sort = MDRectangleFlatButton(text="升序排序", size_hint=(1, None), height=dp(40))
        btn_sort.bind(on_release=lambda x: self.run_sort(True))
        content.add_widget(btn_sort)

        # Groupby
        content.add_widget(MDLabel(text="分组聚合 (列, 聚合值列, 函数):", size_hint_y=None, height=dp(24)))
        self.group_col = MDTextField(hint_text="分组列", size_hint_y=None, height=dp(44))
        content.add_widget(self.group_col)
        self.agg_col = MDTextField(hint_text="聚合值列", size_hint_y=None, height=dp(44))
        content.add_widget(self.agg_col)
        self.agg_func = MDTextField(hint_text="函数 (sum/mean/count)", size_hint_y=None, height=dp(44))
        content.add_widget(self.agg_func)
        btn_group = MDRectangleFlatButton(text="分组聚合", size_hint=(1, None), height=dp(40))
        btn_group.bind(on_release=lambda x: self.run_groupby())
        content.add_widget(btn_group)

        # Transpose
        btn_trans = MDRectangleFlatButton(text="行列转置", size_hint=(1, None), height=dp(40))
        btn_trans.bind(on_release=lambda x: self.run_transpose())
        content.add_widget(btn_trans)

        self.status = MDLabel(text="", size_hint_y=None, height=dp(24))
        content.add_widget(self.status)

        sv.add_widget(content)
        layout.add_widget(sv)
        self.add_widget(layout)

    def on_enter(self):
        pass

    def run_sort(self, asc):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        col = self.sort_col.text.strip()
        if col in merged.columns:
            result = transform_sort(merged, [col], ascending=asc)
            self.store._transform_result = result
            self.status.text = f"排序完成: {len(result)} 行"

    def run_groupby(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        gcol = self.group_col.text.strip()
        acol = self.agg_col.text.strip()
        func = self.agg_func.text.strip() or "sum"
        if gcol in merged.columns and acol in merged.columns:
            result = transform_groupby(merged, [gcol], acol, func)
            self.store._transform_result = result
            self.status.text = f"分组完成: {len(result)} 组"

    def run_transpose(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        result = transpose_dataframe(merged)
        self.store._transform_result = result
        self.status.text = f"转置完成: {len(result)} 行 × {len(result.columns)} 列"

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── Export Screen ─────────────────────────────────────────────────────────

class ExportScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self.exporter = ExcelExporter()
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="💾 导出", elevation=2))
        self.status = MDLabel(text="暂无数据可导出", size_hint_y=None, height=dp(30))
        layout.add_widget(self.status)

        self.filename_input = MDTextField(hint_text="文件名 (可选)", size_hint_y=None, height=dp(44))
        layout.add_widget(self.filename_input)

        btn_all = MDRectangleFlatButton(text="📦 一键打包导出 (多 Sheet)", size_hint=(1, None), height=dp(48),
                                         md_bg_color="#1976D2", text_color="ffffff")
        btn_all.bind(on_release=lambda x: self.export_all())
        layout.add_widget(btn_all)

        btn_single = MDRectangleFlatButton(text="导出当前数据", size_hint=(1, None), height=dp(48))
        btn_single.bind(on_release=lambda x: self.export_current())
        layout.add_widget(btn_single)

        self.add_widget(layout)

    def on_enter(self):
        merged, _ = self.store.get_merged_data()
        self.status.text = f"数据就绪: {len(merged)} 行 × {len(merged.columns)} 列" if merged is not None else "暂无数据"

    def export_all(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            self.show_snackbar("请先加载文件")
            return
        profile = get_column_profile(merged)
        stats = get_overview_stats(merged)
        dedup = getattr(self.store, '_dedup_result', None)
        filtered = getattr(self.store, '_filter_result', None)
        cleaned = getattr(self.store, '_clean_result', None)
        fname = self.filename_input.text.strip() or None
        path = self.exporter.export_all(merged, profile, dedup, filtered, stats, cleaned, fname)
        self.status.text = f"✅ 已导出: {path}"
        self.show_snackbar(f"导出成功: {os.path.basename(path)}")

    def export_current(self):
        merged, _ = self.store.get_merged_data()
        if merged is None:
            return
        fname = self.filename_input.text.strip() or None
        path = self.exporter.export_dataframe(merged, filename=fname)
        self.status.text = f"✅ 已导出: {path}"
        self.show_snackbar("导出成功")

    def show_snackbar(self, text):
        MDSnackbar(text=text, duration=2).open()


# ─── More Screen ───────────────────────────────────────────────────────────

class MoreScreen(MDScreen):
    def __init__(self, store, **kwargs):
        super().__init__(**kwargs)
        self.store = store
        self._build_ui()

    def _build_ui(self):
        layout = MDBoxLayout(orientation="vertical", padding="8dp", spacing="4dp")
        layout.add_widget(MDTopAppBar(title="⚙️ 更多", elevation=2))

        sv = ScrollView()
        content = MDBoxLayout(orientation="vertical", spacing="6dp", size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Quick links to other screens
        links = [
            ("🧹 数据清洗", "cleaner"),
            ("🔄 数据转换", "transform"),
            ("💾 导出", "export"),
            ("🔧 筛选", "filter"),
        ]
        for text, screen_name in links:
            btn = MDRectangleFlatButton(text=text, size_hint=(1, None), height=dp(48))
            btn.bind(on_release=lambda x, sn=screen_name: self.switch_to(sn))
            content.add_widget(btn)

        content.add_widget(MDLabel(text="", size_hint_y=None, height=dp(20)))

        btn_help = MDRectangleFlatButton(text="📖 使用帮助", size_hint=(1, None), height=dp(48))
        btn_help.bind(on_release=lambda x: self.show_help())
        content.add_widget(btn_help)

        self.help_label = MDLabel(text="", size_hint_y=None, height=dp(200))
        content.add_widget(self.help_label)

        self.version_label = MDLabel(text="版本: 1.0.0", size_hint_y=None, height=dp(24), halign="center")
        content.add_widget(self.version_label)

        sv.add_widget(content)
        layout.add_widget(sv)
        self.add_widget(layout)

    def on_enter(self):
        pass

    def switch_to(self, screen_name):
        app = MDApp.get_running_app()
        if hasattr(app, 'root'):
            app.root.current = screen_name

    def show_help(self):
        self.help_label.text = (
            "📖 Excel 表格助手\n\n"
            "1. 文件 — 添加 Excel 文件，选择 Sheet\n"
            "2. 预览 — 查看表头属性和数据\n"
            "3. 查重 — 精确/模糊/跨文件查重\n"
            "4. 统计 — 数值/文本/缺失分析+图表\n\n"
            "支持: .xlsx .xls .csv\n"
            "导出为多 Sheet Excel 文件"
        )


# ─── App ───────────────────────────────────────────────────────────────────

class ExcelAssistantApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.store = FileStore()
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"

    def build(self):
        self.title = APP_TITLE

        # Create screen manager
        sm = MDScreenManager()

        screens = [
            ("file", FileScreen, "📁 文件"),
            ("preview", PreviewScreen, "📋 预览"),
            ("dedup", DedupScreen, "🔍 查重"),
            ("filter", FilterScreen, "🔧 筛选"),
            ("stats", StatsScreen, "📊 统计"),
            ("cleaner", CleanerScreen, "🧹 清洗"),
            ("transform", TransformScreen, "🔄 转换"),
            ("export", ExportScreen, "💾 导出"),
            ("more", MoreScreen, "⚙️ 更多"),
        ]

        for name, cls, label in screens:
            screen = cls(self.store, name=name)
            sm.add_widget(screen)

        # Main layout: ScreenManager + BottomNav
        root = MDBoxLayout(orientation="vertical")

        root.add_widget(sm)

        bottom_nav = MDBottomNavigation(
            panel_color="#f5f5f5",
            selected_color_background="#1976D2",
            text_color_active="#1976D2",
        )

        tabs = [
            ("file", "file-document", "文件"),
            ("preview", "table", "预览"),
            ("dedup", "database-search", "查重"),
            ("stats", "chart-bar", "统计"),
            ("more", "dots-horizontal", "更多"),
        ]

        for name, icon, label in tabs:
            item = MDBottomNavigationItem(name=name, text=label, icon=icon)
            bottom_nav.add_widget(item)

        bottom_nav.bind(on_switch=self.on_tab_switch)
        root.add_widget(bottom_nav)

        self._sm = sm
        return root

    def on_tab_switch(self, nav, tab, switch, *args):
        screen = self._sm.get_screen(tab.name)
        self._sm.current = tab.name
        if hasattr(screen, 'on_enter'):
            screen.on_enter()


if __name__ == "__main__":
    ExcelAssistantApp().run()
