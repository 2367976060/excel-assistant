"""Global configuration for Excel Assistant app."""
import os

APP_TITLE = "Excel 表格助手"
APP_VERSION = "1.0.0"
SUPPORTED_EXTENSIONS = [".xlsx", ".xls", ".csv"]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

# Column type icons for display
COLUMN_TYPE_ICONS = {
    "numerical": "numeric",
    "text": "format-text",
    "datetime": "calendar",
    "boolean": "check-circle-outline",
    "other": "help-circle-outline",
}

# Color theme
PRIMARY_COLOR = "#1976D2"
ACCENT_COLOR = "#FF6F00"
ERROR_COLOR = "#D32F2F"
SUCCESS_COLOR = "#388E3C"
